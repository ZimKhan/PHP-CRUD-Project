<?php
  $conn=mysqli_connect('localhost','root','','php_practice');
  $sql="SELECT * FROM students";
  $result=mysqli_query($conn,$sql);
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-grid.min.css">
    <link rel="stylesheet" href="css/bootstrap-reboot.min.css">
    <title>CRUD</title>
  </head>
  <body>
  <br><br><br>
  <h1>PHP CRUD Project</h1>
    <div class="container">
        <div class="row">
            <div class="col-md-3">
            <h3>Add New Student</h3>
                <a href="insert.php" class="btn btn-info">New Students</a>
            </div>
            <div class="col-md-9">
            <h3>Student List</h3>
              <table class="table">
                <thead>
                  <th>Id</th>
                  <th>Name</th>
                  <th>Age</th>
                  <th>Email</th>
                  <th>Actions</th>
                </thead>
                <tbody>
                <?php while($row=mysqli_fetch_assoc($result)){?>
                  <tr>
                  <td><?php echo $row['id'];?></td>
                  <td><?php echo $row['name'];?></td>
                  <td><?php echo $row['age'];?></td>
                  <td><?php echo $row['email'];?></td>
                  <td>
                    <a href="view.php?id=<?php echo $row['id'];?>" class="btn btn-success">View</a>
                    <a href="edit.php?id=<?php echo $row['id'];?>" class="btn btn-warning">Edit</a>
                    <a href="delete.php?id=<?php echo $row['id'];?>" class="btn btn-danger" onclick="return confirm('Are you sure')">Delete</a>
                  </td>
                  </tr>
                <?php }?>
                </tbody>
              </table>
            </div>
        </div>
    </div>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>