<?php
  $id = $_GET['id'];
  $conn=mysqli_connect('localhost','root','','php_practice');
  $sql="SELECT * FROM students WHERE id=$id";
  $result=mysqli_query($conn,$sql);
  $std=mysqli_fetch_assoc($result);
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-grid.min.css">
    <link rel="stylesheet" href="css/bootstrap-reboot.min.css">
    <title>CRUD</title>
  </head>
  <body>
  <br><br><br>
  <h1>PHP CRUD Project</h1>
    <div class="container">
        <div class="row">
            <div class="col-md-3">
            <h3>Student List</h3>
                <a href="index.php" class="btn btn-info">Student List</a>
            </div>
            <div class="col-md-9">
            <h3>Edit Student</h3>
              


            <form action="update.php?id=<?php echo $id?>" method="post">
                <div class="form-group">
                    <label for="Name">Name:</label>
                    <input required type="text" class="form-control" name="name" placeholder="Student Name" value="<?php echo $std['name']?>">
                </div>
                <div class="form-group">
                    <label for="Age">Age:</label>
                    <input required type="text" class="form-control" name="age" placeholder="Student Age" value="<?php echo $std['age']?>">
                </div>
                <div class="form-group">
                    <label for="Email">Email:</label>
                    <input required type="text" class="form-control" name="email" placeholder="Student Roll" value="<?php echo $std['email']?>">
                </div>

                <button type="submit" class="btn btn-primary">Submit</button>
            </form>



            </div>
        </div>
    </div>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>