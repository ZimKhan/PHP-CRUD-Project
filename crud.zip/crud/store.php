<?php
    $name=$_POST['name'];
    $age=$_POST['age'];
    $email=$_POST['email'];
    $conn=mysqli_connect('localhost','root','','php_practice');
    $sql="INSERT INTO students VALUES(NULL,'$name','$age','$email')";
    if(mysqli_query($conn,$sql)){
        header("Location:index.php");
    }else{
        echo "Not Inserted";
    }

?>