<?php
  $id = $_GET['id'];
  $conn=mysqli_connect('localhost','root','','php_practice');
  $sql="SELECT * FROM students WHERE id=$id";
  $result=mysqli_query($conn,$sql);
  $std=mysqli_fetch_assoc($result);
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-grid.min.css">
    <link rel="stylesheet" href="css/bootstrap-reboot.min.css">
    <title>CRUD</title>
  </head>
  <body>
  <br><br><br>
  <h1>PHP CRUD Project</h1>
    <div class="container">
        <div class="row">
            <div class="col-md-3">
            <h3>Student List</h3>
                <a href="index.php" class="btn btn-info">Student List</a>
            </div>
            <div class="col-md-9">
            <h3>Student Information</h3>
              <table class="table">
                <tr>
                    <th>Name:</th>
                    <td><?php echo $std['name'];?></td>
                </tr>
                <tr>
                    <th>Age:</th>
                    <td><?php echo $std['age'];?></td>
                </tr>
                <tr>
                    <th>Email:</th>
                    <td><?php echo $std['email'];?></td>
                </tr>
              </table>
            </div>
        </div>
    </div>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>