<?php
  $id = $_GET['id'];
  $conn=mysqli_connect('localhost','root','','php_practice');
  $sql="DELETE FROM students WHERE id=$id";
  if(mysqli_query($conn,$sql)){
      header("Location:index.php");
  }else{
      echo "Not Deleted";
  };

?>