<?php
  $conn=mysqli_connect('localhost','root','','php_practice');
  $sql="SELECT * FROM students";
  $result=mysqli_query($conn,$sql);
?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-grid.min.css">
    <link rel="stylesheet" href="css/bootstrap-reboot.min.css">
    <title>CRUD</title>
  </head>
  <body>
  <br><br><br>
  <h1>PHP CRUD Project</h1>
    <div class="container">
        <div class="row">
            <div class="col-md-3">
            <h3>Student List</h3>
                <a href="index.php" class="btn btn-info">Student List</a>
            </div>
            <div class="col-md-9">
            <h3>Add New Student</h3>
              


            <form action="store.php" method="post">
                <div class="form-group">
                    <label for="Name">Name:</label>
                    <input required type="text" class="form-control" name="name" placeholder="Student Name">
                </div>
                <div class="form-group">
                    <label for="Age">Age:</label>
                    <input required type="text" class="form-control" name="age" placeholder="Student Age">
                </div>
                <div class="form-group">
                    <label for="Email">Email:</label>
                    <input required type="text" class="form-control" name="email" placeholder="Student Roll">
                </div>

                <button type="submit" class="btn btn-primary">Submit</button>
            </form>



            </div>
        </div>
    </div>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>